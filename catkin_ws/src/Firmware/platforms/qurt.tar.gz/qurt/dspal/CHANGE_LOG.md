# DSPAL

Version Number: 1.1

Date: 08/04/2016

- Addition of support for running individual tests from the dspal_tester command line.  Adds an additional test for testing the frequency of FARF debug output.

- Addition of PWM support to the DSPAL API, including unit test coverage in dspal_tester if the correct version of the aDSP firmware is detected.

Version Number: 1.2

Date: 08/31/2016

- Addition of support for the POSIX termios API to perform UART configuration.

Version Number: 1.3

Date: 10/04/2016

- Addition of support for dlopen, dlclose, dlsym and dlerror to support the loading of dynamic libraries from other dynamic libriaries running on the Hexagon processor.


