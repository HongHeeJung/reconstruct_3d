#include "stub_daemon.h"


void init_app_map(apps_map_type &apps) {stub_init_app_map_callback(apps);}

void list_builtins(apps_map_type &apps) {stub_list_builtins_callback(apps);}
