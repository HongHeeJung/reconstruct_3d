# MATLAB Derivations

This folder contains the derivations and test suites in Matlab for ECL components.
