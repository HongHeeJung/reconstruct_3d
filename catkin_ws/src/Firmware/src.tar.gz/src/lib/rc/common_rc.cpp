
#include "common_rc.h"

__EXPORT rc_decode_buf_t rc_decode_buf;
