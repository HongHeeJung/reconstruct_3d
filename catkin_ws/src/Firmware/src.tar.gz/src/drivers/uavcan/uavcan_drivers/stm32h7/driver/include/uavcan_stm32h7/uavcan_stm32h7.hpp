/*
 * Copyright (C) 2014 Pavel Kirienko <pavel.kirienko@gmail.com>
 */

#pragma once

#include <uavcan/uavcan.hpp>

#include <uavcan_stm32h7/thread.hpp>
#include <uavcan_stm32h7/clock.hpp>
#include <uavcan_stm32h7/can.hpp>
