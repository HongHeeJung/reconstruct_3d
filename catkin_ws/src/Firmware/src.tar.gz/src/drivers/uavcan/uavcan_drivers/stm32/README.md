STM32 platform driver
=====================

The directory `driver` contains the STM32 platform driver for Libuavcan.

A dedicated example application may be added later here.
For now, please consider the following open source projects as a reference:

- https://github.com/PX4/sapog
- https://github.com/Zubax/zubax_gnss
- https://github.com/PX4/Firmware
