import unittest
from uavcan.dsdl import parser


# TODO once module structure is clearer


if __name__ == '__main__':
    unittest.main()
