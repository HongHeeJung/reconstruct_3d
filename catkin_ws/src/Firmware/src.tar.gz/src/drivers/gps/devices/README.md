### GPS Drivers ###

This repository contains user-space gps drivers, used as a submodule in
[PX4 Firmware](https://github.com/PX4/Firmware) and
[QGroundControl](https://github.com/mavlink/qgroundcontrol).

All platform-specific stuff is done via a callback function and a
`definitions.h` header file.

